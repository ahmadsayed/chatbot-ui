// JavaScript Document
 $('.chatbox').animate({scrollTop: $('.chatbox').prop("scrollHeight")},500 );